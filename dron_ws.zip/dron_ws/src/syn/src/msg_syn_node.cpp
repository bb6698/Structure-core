#include <ros/ros.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/Image.h>

using namespace sensor_msgs;
using namespace message_filters;
using namespace ros;

void callback(const ImageConstPtr& image, const ImuConstPtr& imu_data)
  {
    // Solve all of perception here...
  }
  
int main(int argc, char** argv)
  {
    ros::init(argc, argv, "messages_syn");
  
    //ros::NodeHandle nh;
  
    //message_filters::Subscriber<Image> image_sub(nh, "image", 1);
    //message_filters::Subscriber<Imu> imu_data_sub(nh, "imu_data", 1);
    //TimeSynchronizer<Image, Imu> sync(image_sub, imu_data_sub, 10);
    //sync.registerCallback(boost::bind(&callback, _1, _2));
  //
    //ros::spin();
  
    return 0;
  }